#!/usr/bin/perl

@sync = (
	{ host => "laptop",
		src  => "C:/SysArch/Notes/Labs/ARM",
		dest => "E:/Notes/Labs/ARM" },
	{ host => "PC11210",
		src  => "D:/units/SysArch/Lab04-05",
		dest => "F:/Notes/Labs/ARM" }
);

$target = $ARGV[0];
$target = "book" unless $target;

$jump = "make_" . $target;

if ( exists &$jump ) {
	# Call the make_<target> function
	do $jump();
} else {
	# Target not found - we don't know how to make it
	print <<EOT
clean	Remove all generated files
sync	x
EOT
}

exit;

# ==========
# older(a,b) - True if a is older than b
# ==========

sub older {
	local ($a,$b) = @_;
	if ( -e $b ) {
		if ( -M $a <= -M $b ) {
			return 0;	# a more recent than b
		} else {
			return 1;	# a older than b
		}
	} else {
		return 1;
	}
}

# =========
# Check DVI - Return true if an .aux is older than a .tex
# =========

sub checkdvi {
	local($dir) = @_;
	local(*DIR,@dirs,@aux);
	local($name,$value,$aux,$tex);

	opendir(DIR,$dir);
	foreach $name (readdir(DIR)) {
		next if substr($name,0,1) eq ".";
		push(@dirs,$name) if -d $dir . "/" . $name;
		push(@aux,$name) if substr($name,-3) eq "aux";
	}
	closedir(DIR);

	$value = 0;

	# Check files first
	foreach $name (@aux) {
		$aux = -M $dir . "/" . $name;
		$tex = -M $dir . "/" . substr($name,0,-3) . "tex";

		# Rebuild .dvi if .aux older than .tex
		if ( $tex < $aux ) {
			$value = 1;
			last;
		}
	}

	# Check sub-directories only if not true yet
	unless ($value) {
		foreach $name (@dirs) {
			if ( checkdvi($dir . "/" . $name) ) {
				$value = 1;
				last;
			}
		}
	}
	
	return $value;
}

sub remove {
	if ( -e $_[0] ) {
		print "rm: ", $_[0], "\n";
		unlink($_[0]);
	}
}

sub remove_files {
	local($ext,$dir) = @_;
	local(*DIR,$dname,$name);

	$dir = "." unless $dir;

	opendir(DIR,$dir);
	foreach $name (readdir(DIR)) {
		next if substr($name,0,1) eq ".";
		$dname = $dir . "/" . $name;
		if ( -d $dname ) { remove_files($ext, $dname) }
		if ( substr($name, 0 - length($ext) ) eq $ext ) {
			remove($dname);
		}
	}
	closedir(DIR);
}



# ==========
# make tidy - Remove all intermediate files
# ==========

sub make_tidy {
	# Remove LaTeX auxiliary files
	remove_files(".aux");
	
	# Remove addition front matter
	remove("book.toc");		# Table of Contents
	remove("book.lof");		# List of Figures
	remove("book.lot");		# List of Tables
	remove("book.lop");		# List of Programs
	remove("book.out");		# PDF Bookmarks

	# Remove the BibTeX files
	remove("book.bbl");		# Bibliography

	# Remove the MakeIndex files
	remove("book.idx");		# Index source
	remove("book.ind");		# Index
}

# ==========
# make clean - Remove all generated files
# ==========

sub make_clean {
	make_tidy();
	remove_files(".undo");		# LEd backup files

	# Remove final targets
	remove("book.dvi");		# LaTeX target
	remove("book.ps");		# PostScript
	remove("book.pdf");		# PDF

	# Remove the Logs
	remove("book.log");		# LaTeX log
	remove("book.blg");		# BibTeX log
	remove("book.ilg");		# Makeindex Log
}


# ==========
# make sync
# ==========

sub make_sync {
	local $name = $ENV{COMPUTERNAME};
	local $item;
	local $SRC, $DEST;

	# Scan @sync for this computer

	foreach $item ( @sync ) {
		if ( lc($name) eq lc($$item{host}) ) {
			$SRC  = $$item{src};
			$DEST = $$item{dest};
			syncdir($SRC, $DEST);

			sleep(1);
			$SRC  = $$item{dest};
			$DEST = $$item{src};
			syncdir($SRC, $DEST);
			last;
		}
	}

	unless ( $SRC ) {
		print "Don't know how to sync on ", $name, "\n";
	}
}


sub copy {
	local ($src, $dest) = @_;

	$src  =~ s"/"\\\\"g;
	$dest =~ s"/"\\\\"g;

	system("make.bat __copy " . $src . " " . $dest);
}

#sub copy {
#	local ($src,$dest) = @_;
#	local (*IN,*OUT);
#
#	open(IN,$src) or die("Can't open $src: $!\n");
#	open(OUT,">$dest") or die("Can't opne $dest: $!\n");
#	binmode(OUT) if -B $src;
#
#	while(!eof(IN)) {
#		print OUT <IN>;
#	}
#
#	close(IN);
#	close(OUT);
#}

sub syncdir {
	local ($src,$dest) = @_;
	local (*DIR);
	local (@dirs,@files,$name);
	local ($sfile,$dfile);

	# Scan dir on source
	opendir(DIR,$src) or die("Can't access $src: $!\n");
	foreach $name (readdir(DIR)) {
		next if substr($name,0,1) eq ".";
		if ( -d $src . "/" . $name ) {
			push(@dirs,$name);
		} else {
			push(@files,$name);
		}
	}
	closedir(DIR);

	# Check files on dest
	foreach $name (@files) {
		$dname = $dest . "/" . $name;
		$sname = $src  . "/" . $name;

		if ( -e $dname ) {
			# File exists on dest is it older?
			if ( older( $dname, $sname) ) {
				print "Update: ", substr($sname, length($SRC)+1), "\n";
				copy($sname,$dname);
			}
		} else {
			# File is new
			print "   New: ", substr($sname, length($SRC)+1), "\n";
			copy($sname,$dname);
		}
	}

	# Check directories
	foreach $name (sort @dirs) {
		$dname = $dest . "/" . $name;
		$sname = $src  . "/" . $name;

		if ( -e $dest . "/" . $name ) {
			syncdir( $sname, $dname );
		} else {
			print "Create: ", substr($dname, length($DEST)+1), "\n";
			mkdir($dname);
			syncdir( $sname, $dname );
		}
	}
}
