*	Count the number of negative values in a table of 32-bit numbers

	TTL	Ch5Ex3
	AREA	Program, CODE, READONLY	
	ENTRY
	
Main
	LDR	R0, =Table		; load the address of the lookup table
	EOR	R1, R1, R1		; clear R1 to store count
	LDR	R2, Length		; init element count
	CMP	R2, #0			; is table empty?
	BEQ	Done			; Yes => Skip loop
Loop
	LDR	R3, [R0]		; Read data from table
	CMP	R3, #0			; Is value < 0
	BPL	Looptest		; Yes => skip next line
	ADD	R1, R1, #1		; No  => increment -ve number count
Looptest
	ADD	R0, R0, #+4		; increment pointer
	SUBS	R2, R2, #0x1		; decrement loop count
	BNE	Loop			; repeat unless count is zero
Done
	STR	R1, Result		; store result
	SWI	&11

	AREA	Data1, DATA

Table	DCD	&F1522040		; table of values to be added
	DCD	&7F611C22
	DCD	&80000242
TablEnd	DCD	0

	AREA	Data2, DATA
Length	DCW	(TablEnd - Table) / 4	; gives the loop count
Result	DCW	0			; storage for result

	END
