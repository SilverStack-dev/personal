*	Find largest unsigned 32 bit value in a table

	TTL	Ch5Ex5
	AREA	Program, CODE, READONLY	
	ENTRY

Main
	LDR	R0, =Table		; load the address of the lookup table
	EOR	R1, R1, R1		; clear Max
	LDR	R2, Length		; init loop count
	CMP	R2, #0			; is Loop Count empty?
	BEQ	Done			; Yes => No table to search!
Loop
	LDR	R3, [R0]		; Get the data
	CMP	R3, R1			; Is it Lower or Same as current Max ?
	BLS	Looptest		; Yes => skip next line
	MOV	R1, R3			; No  => Make this the current Max
Looptest
	ADD	R0, R0, #+4		; increment pointer
	SUBS	R2, R2, #0x1		; decrement loop count
	BNE	Loop			; Repeat if loop count not zero
Done
	STR	R1, Result		; store result
	SWI	&11

	AREA	Data1, DATA

Table	DCW	&A152			; table of values to be tested
	DCW	&7F61
	DCW	&F123
	DCW	&8000
TablEnd	DCD	0

	AREA	Data2, DATA

Length	DCW	(TablEnd - Table) / 4	; Calculste the loop count
Result	DCW	0			; storage for result

	END
