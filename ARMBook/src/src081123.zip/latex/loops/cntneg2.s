*	Count the number of negative values in a table of 32-bit numbers

	TTL	Ch5Ex4
	AREA	Program, CODE, READONLY	
	ENTRY

Main
	LDR	R0, =Table		; load the address of the lookup table
	EOR	R1, R1, R1		; clear R1 to store count
	LDR	R2, Length		; init element count
	CMP	R2, #0			; is table empty?
	BEQ	Done			; Yes => No need to scan it
Loop
	LDR	R3, [R0]		; get the data
	MOV	R3, R3 LSL #1		; Shift top bit into Carry
	ADDCS	R1, R1, #1		; Inc NegCount if Carry Set
	ADD	R0, R0, #+4		; Increment pointer
	SUBS	R2, R2, #0x1		; Decrement Loop Count
	BNE	Loop			; Repeat Loop if Count not zero
Done
	STR	R1, Result		; Store result
	SWI	&11

	AREA	Data1, DATA

Table	DCD	&F1522040		; table of values to be added
	DCD	&7F611C22
	DCD	&80000242
TablEnd	DCD	0

	AREA	Data2, DATA
Length	DCW	(TablEnd - Table) / 4	; Calculate the loop count
Result	DCW	0			; Storage for result

	END
