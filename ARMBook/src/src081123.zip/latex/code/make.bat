@echo off
set asm=C:\ARM\BIN\ARMASM -LI -CPU ARM6 -list

if x%1 == x	 goto all
if x%1 == xall	 goto all
if x%1 == xclean goto clean

if NOT EXIST %1.s goto notfound

%asm% %1.list %1.s
del %1.o
goto end

:notfound
echo Target %1.s not found
goto end

:all
for %%f in (*.s) do %asm% %%f.list %%f
goto end

:clean
for %%f in (*.o) do del %%f
for %%f in (*.list) do del %%f
goto end

:end