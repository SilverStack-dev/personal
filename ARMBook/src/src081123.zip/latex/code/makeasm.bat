set asm=D:\ARMulator\BIN\ARMASM -LI -CPU ARM6 -list

for %%n in (1 2 3 4 5 6 7 8 9) do %asm% Ch4Ex%%n.list Ch4Ex%%n.s
for %%n in (1 2 3 4 5 6) do %asm% Ch5Ex%%n.list Ch5Ex%%n.s
for %%n in (1 2 3 4 5 6 7) do %asm% Ch6Ex%%n.list Ch6Ex%%n.s
for %%n in (1 2 3 4 5 6 7) do %asm% Ch7Ex%%n.list Ch7Ex%%n.s
for %%n in (1 2 3 4) do %asm% Ch8Ex%%n.list Ch8Ex%%n.s
for %%n in (1 2 3 4 5) do %asm% Ch9Ex%%n.list Ch9Ex%%n.s
for %%n in (1 2 3 3a 4 5 6 7) do %asm% Ch10Ex%%n.list Ch10Ex%%n.s

goto end

4: 1 2 3 4 5 6 7 8 9
5: 1 2 3 4 5 6
6: 1 2 3 4 5 6 7
7: 1 2 3 4 5 6 7
8: 1 2 3 4
9: 1 2 3 4 5
10: 1 2 3 3a 4 5 6 7

:end
