@echo off

set target=%1%
set obj=book
set latex=latex

if x%COMPUTERNAME% == xLAPTOP  set ZIP=E:\labbook.zip
if x%COMPUTERNAME% == xPC11210 set ZIP=F:\labbook.zip

if x%1% == x__copy goto copy

:args
if x%1% == x       goto once
if x%1% == xonce   goto once
if x%1% == xbook   goto once

if x%1% == xdvi    goto dvi
if x%1% == xps     goto ps
if x%1% == xpdf    goto pdf

if x%1% == xall    goto dvi
if x%1% == xfull   goto dvi

if x%1% == xclean  goto perl
if x%1% == xtidy   goto perl
if x%1% == xsync   goto perl

if x%1% == xin     goto checkin
if x%1% == xout    goto checkout

echo Unknown target: %1%
goto end

:pdf
set latex=pdflatex
shift
goto args

:dvi
set latex=latex
shift
goto args

:all
%latex% %obj%
bibtex  %obj%
%latex% %obj%
%latex% %obj%
makeindex -s index.ist %obj%
:once
%latex% %obj%

if x%target% != xps goto end

:ps
if NOT EXIST %obj%.dvi goto dvi
dvips -Pcmz -Pamz -K -q -t a4 -o %obj%.ps %obj%
goto end

:checkin
perl %0.pl clean
zip -ur %ZIP% .
goto end

:checkout
unzip -uo %ZIP%
goto end

:perl
set  oldpath=%path%
path .;%path%
perl %0.pl %target%
path %oldpath%
goto end

:copy
copy %2 %3

:end
